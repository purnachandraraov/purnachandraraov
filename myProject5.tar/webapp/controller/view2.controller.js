sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    
    return Controller.extend("home.controller.view2",{
        init:function(){

        }
       
    })

});