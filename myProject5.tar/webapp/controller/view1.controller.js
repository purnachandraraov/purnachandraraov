sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'sap/m/MessageBox'
], function(Controller,MessageBox) {
    'use strict';
    
    return Controller.extend("home.controller.view1",{
        init:function(){

        },

        oEdesigPopup : null,
     onfilter:function(oEvent){
            if(!this.oEdesigPopup){
                 this.oEdesigPop=new sap.ui.xmlfragment("home.fragment.popup",this)
                 this.getView().addDependent(this.oEdesigPopup);
                                  }
                 this.oEdesigPop().bindAggregation("items",{
                     path:"{/Edesig}",
                     template: new sap.m.StandardListItem({
                        description:"{Ename}",
                        intro:"{Edept}",
                        icon:"sap-icon://map"
                     })
                 });                 
               this.oEdesigPop.open();
        //  MessageBox.confirm("under construction");
     }
        
    })

});