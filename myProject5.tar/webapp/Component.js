sap.ui.define([
    "sap/ui/core/UIComponent"
], function(UIComponent) {
    'use strict';
    
    return UIComponent.extend("home.Component",{

        metadata:{
            manifest: "json"
        },

        init: function(){
            //This line will call the base class constructor 
            UIComponent.prototype.init.apply(this);
        },

        createContent: function(){

            var oXMLView = sap.ui.core.mvc.ViewType.XML;

            var oView = sap.ui.view({
                viewName : "home.view.App",
                id: "idAppView",
                type: "XML"
            });

            //Step - 1 : Instantiate all views
            var oview1 = sap.ui.view({
                viewName : "home.view.view1",
                id: "idview1",
                type: "XML"
            });

            var oview2 = sap.ui.view({
                viewName: "home.view.view2",
                id:"idview2",
                type: oXMLView
            });
            
            var oApp = oView.byId("App");

            oApp.addPage(oview1);
            oApp.addPage(oview2);

            return oView;
        }

        });
});